package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import br.unicentro.sistemaderestaurante.dao.PratoDAO;
import br.unicentro.sistemaderestaurante.main.Gerenciadortela;
import br.unicentro.sistemaderestaurante.model.ItemPedido;
import br.unicentro.sistemaderestaurante.model.Pedido;
import br.unicentro.sistemaderestaurante.model.Prato;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class AdminController {

    private static final String FK_VIOLADA = "23503";
    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    //pratos
    @FXML private TableView<Prato> tabelaPratos;
    @FXML private TableColumn<Prato, Integer> colPratoId;
    @FXML private TableColumn<Prato, String> colPratoNome;
    @FXML private TableColumn<Prato, String> colPratoPreco;
    @FXML private TableColumn<Prato, Integer> colPratoFuncionario;
    @FXML private TextField txtPratoNome;
    @FXML private TextField txtPratoPreco;
    @FXML private TextField txtPratoFuncionario;

    // pedidos
    @FXML private TableView<Pedido> tabelaPedidos;
    @FXML private TableColumn<Pedido, Integer> colPedidoId;
    @FXML private TableColumn<Pedido, String> colPedidoData;
    @FXML private TableColumn<Pedido, Integer> colPedidoMesa;
    @FXML private TableView<ItemPedido> tabelaItens;
    @FXML private TableColumn<ItemPedido, String> colItemPrato;
    @FXML private TableColumn<ItemPedido, Integer> colItemQtd;
    @FXML private TableColumn<ItemPedido, String> colItemSubtotal;
    @FXML private TextField txtPedidoMesa;
    @FXML private Spinner<Integer> spQtdItem;
    @FXML private Label lblTotalPedido;

    @FXML private Label lblMensagem;

    private final PratoDAO pratoDAO = new PratoDAO();
    private final PedidoDAO pedidoDAO = new PedidoDAO();

    @FXML
    public void initialize() {
        // Pratos
        //configura as colunas da tabela pratos e formata para o preço padrão
        //o property é usado para chama o getter da classe pelo nome
        colPratoId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colPratoNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colPratoPreco.setCellValueFactory(c ->
                //para o preço usei um lambda, pra manter o formato em vez do double
                new SimpleStringProperty(String.format("R$ %.2f", c.getValue().getPreco())));
        colPratoFuncionario.setCellValueFactory(new PropertyValueFactory<>("funcionarioId"));

        //quando um usuário selecionar um prato da tabela, o formulário é preenchido com os novos dados dele
        tabelaPratos.getSelectionModel().selectedItemProperty().addListener((obs, antigo, novo) -> preencherFormularioPrato(novo));

        // Pedidos
        colPedidoId.setCellValueFactory(new PropertyValueFactory<>("id"));

        colPedidoData.setCellValueFactory(c ->
                new SimpleStringProperty(c.getValue().getDataHora().format(FORMATO_DATA)));
        colPedidoMesa.setCellValueFactory(new PropertyValueFactory<>("mesaid"));

        //coluna da tabela de itens
        colItemPrato.setCellValueFactory(new PropertyValueFactory<>("nomePrato"));
        colItemQtd.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
        colItemSubtotal.setCellValueFactory(c ->
                new SimpleStringProperty(String.format("R$ %.2f", c.getValue().getSubtotal())));

        //spinner de quantidade, com máximo e mínimo
        spQtdItem.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 99, 1));

        //quando o pedido é selecionado carrega as informações dele
        tabelaPedidos.getSelectionModel().selectedItemProperty().addListener((obs, antigo, novo) -> aoSelecionarPedido(novo));
        //ao selecionar um item, o spinner mostra a quantidade dele
        tabelaItens.getSelectionModel().selectedItemProperty().addListener((obs, antigo, novo) -> {
            if (novo != null) spQtdItem.getValueFactory().setValue(novo.getQuantidade());
        });

        //carga inicial de dados e limpa a mensagem
        carregarPratos();
        carregarPedidos();
        lblMensagem.setText("");
    }

    // pratos

    //busca todos os pratos no banco e atualiza a tabela
    @FXML
    private void carregarPratos() {
        try {
            tabelaPratos.setItems(FXCollections.observableArrayList(pratoDAO.listarTodos()));
        } catch (SQLException e) {
            mostrarMensagem("Não foi possível carregar os pratos do banco.", true);
            e.printStackTrace();
        }
    }
    //aqui alem de salvar o prato selecionado, valida os campos antes de enviar ao banco e trata alguns erros comuns
    @FXML
    private void salvarPrato() {
        //só pode modificar o prato se selecionado
        Prato selecionado = tabelaPratos.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            mostrarMensagem("Selecione um prato na tabela para modificar.", true);
            return;
        }

        //valida o nome, o trim tira os espaços no começo e fim
        String nome = txtPratoNome.getText().trim();
        if (nome.isEmpty()) {
            mostrarMensagem("Informe o nome do prato.", true);
            return;
        }

        //o replace é para poder digitar , pq o double só aceita .
        try {
            double preco = Double.parseDouble(txtPratoPreco.getText().trim().replace(',', '.'));
            int funcionarioId = Integer.parseInt(txtPratoFuncionario.getText().trim());
            if (preco < 0) {
                mostrarMensagem("O preço não pode ser negativo.", true);
                return;
            }
            //aqui é o inicio da substituição, então ele cria um prato com o mesmo id e os novos valores e manda para atualizar no banco
            pratoDAO.atualizar(new Prato(selecionado.getId(), nome, preco, funcionarioId));
            carregarPratos(); // ele atualiza a tabela para mostrar a mudança
            mostrarMensagem("Prato atualizado com sucesso.", false);
        } catch (NumberFormatException e) {
            //caso preço ou id sejam letras
            mostrarMensagem("Preço e ID do funcionário devem ser números válidos.", true);
        } catch (SQLException e) {
            //se o funcionário não existe o banco vai rejeitar
            if (FK_VIOLADA.equals(e.getSQLState())) {
                mostrarMensagem("Não existe funcionário com esse ID.", true);
            } else {
                mostrarMensagem("Erro ao atualizar o prato no banco.", true);
            }
            e.printStackTrace();
        }
    }

    //exlui o prato com uma confirmação antes
    @FXML
    private void excluirPrato() {
        Prato selecionado = tabelaPratos.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            mostrarMensagem("Selecione um prato na tabela para excluir.", true);
            return;
        }
        if (!confirmar("Excluir o prato \"" + selecionado.getNome() + "\" do banco de dados?")) {
            return;
        }

        try {
            pratoDAO.excluir(selecionado.getId());
            carregarPratos();
            mostrarMensagem("Prato excluído.", false);
        } catch (SQLException e) {
            //se o prato pertence a um pedido não pode excluir
            if (FK_VIOLADA.equals(e.getSQLState())) {
                mostrarMensagem("Este prato já foi usado em pedidos e não pode ser excluído.", true);
            } else {
                mostrarMensagem("Erro ao excluir o prato no banco.", true);
            }
            e.printStackTrace();
        }
    }

    private void preencherFormularioPrato(Prato prato) {
        if (prato == null) {
            txtPratoNome.clear();
            txtPratoPreco.clear();
            txtPratoFuncionario.clear();
            return;
        }
        txtPratoNome.setText(prato.getNome());
        //o locate serve para garantir o ponto como um separador decimal no campo de edição
        txtPratoPreco.setText(String.format(Locale.US, "%.2f", prato.getPreco()));
        txtPratoFuncionario.setText(String.valueOf(prato.getFuncionarioId()));
    }

    // pedidos

    @FXML
    private void carregarPedidos() {
        try {
            tabelaPedidos.setItems(FXCollections.observableArrayList(pedidoDAO.listarTodos()));
        } catch (SQLException e) {
            mostrarMensagem("Não foi possível carregar os pedidos do banco.", true);
            e.printStackTrace();
        }
    }

    private void aoSelecionarPedido(Pedido pedido) {
        if (pedido == null) {
            txtPedidoMesa.clear();
            tabelaItens.getItems().clear();
            lblTotalPedido.setText("");
            return;
        }
        txtPedidoMesa.setText(String.valueOf(pedido.getMesaid()));
        carregarItens(pedido);
    }

    private void carregarItens(Pedido pedido) {
        try {
            var itens = pedidoDAO.listarItens(pedido.getId());
            tabelaItens.setItems(FXCollections.observableArrayList(itens));

            //soma para ver o total
            double total = 0;
            for (ItemPedido item : itens) {
                total += item.getSubtotal();
            }
            lblTotalPedido.setText(String.format("Total do pedido: R$ %.2f", total));
        } catch (SQLException e) {
            mostrarMensagem("Não foi possível carregar os itens do pedido.", true);
            e.printStackTrace();
        }
    }

    //atualiza a mesa do pedido selecionado com o valor digitado no campo
    @FXML
    private void salvarMesaPedido() {
        Pedido pedido = tabelaPedidos.getSelectionModel().getSelectedItem();
        if (pedido == null) {
            mostrarMensagem("Selecione um pedido na tabela.", true);
            return;
        }

        try {
            int mesaId = Integer.parseInt(txtPedidoMesa.getText().trim());
            pedidoDAO.atualizarMesa(pedido.getId(), mesaId);
            carregarPedidos();
            mostrarMensagem("Mesa do pedido " + pedido.getId() + " atualizada.", false);
        } catch (NumberFormatException e) {
            mostrarMensagem("Informe um número de mesa válido.", true);
        } catch (SQLException e) {
            if (FK_VIOLADA.equals(e.getSQLState())) {
                mostrarMensagem("Não existe mesa com esse ID.", true);
            } else {
                mostrarMensagem("Erro ao atualizar a mesa no banco.", true);
            }
            e.printStackTrace();
        }
    }

    @FXML
    private void alterarQuantidadeItem() {
        Pedido pedido = tabelaPedidos.getSelectionModel().getSelectedItem();
        ItemPedido item = tabelaItens.getSelectionModel().getSelectedItem();
        if (pedido == null || item == null) {
            mostrarMensagem("Selecione um pedido e um item para alterar a quantidade.", true);
            return;
        }

        try {
            spQtdItem.increment(0); // é um truque para não mudar o valor mas força a confirmação
            Integer quantidade = spQtdItem.getValue();
            if (quantidade == null || quantidade < 1 || quantidade > 99) {
                mostrarMensagem("Informe uma quantidade entre 1 e 99.", true);
                return;
            }

            //o item é identificado pela combinação do id do pedido e do prato
            pedidoDAO.atualizarQuantidadeItem(pedido.getId(), item.getPratoID(), quantidade);
            carregarItens(pedido);
            mostrarMensagem("Quantidade atualizada.", false);
        } catch (RuntimeException e) {
            mostrarMensagem("Informe uma quantidade válida (1 a 99).", true);
        } catch (SQLException e) {
            mostrarMensagem("Erro ao atualizar a quantidade no banco.", true);
            e.printStackTrace();
        }
    }

    //remove o item selecionado com uma confirmação antes
    @FXML
    private void excluirItem() {
        Pedido pedido = tabelaPedidos.getSelectionModel().getSelectedItem();
        ItemPedido item = tabelaItens.getSelectionModel().getSelectedItem();
        if (pedido == null || item == null) {
            mostrarMensagem("Selecione um pedido e um item para excluir.", true);
            return;
        }
        if (!confirmar("Remover \"" + item.getNomePrato() + "\" do pedido " + pedido.getId() + "?")) {
            return;
        }

        try {
            pedidoDAO.excluirItem(pedido.getId(), item.getPratoID());
            carregarItens(pedido);
            mostrarMensagem("Item removido do pedido.", false);
        } catch (SQLException e) {
            mostrarMensagem("Erro ao remover o item no banco.", true);
            e.printStackTrace();
        }
    }

    //exclui um pedido com a corfirmação antes
    @FXML
    private void excluirPedido() {
        Pedido pedido = tabelaPedidos.getSelectionModel().getSelectedItem();
        if (pedido == null) {
            mostrarMensagem("Selecione um pedido na tabela para excluir.", true);
            return;
        }
        if (!confirmar("Excluir o pedido " + pedido.getId() + " e todos os seus itens?")) {
            return;
        }

        try {
            pedidoDAO.excluirPedido(pedido.getId());
            carregarPedidos();
            mostrarMensagem("Pedido " + pedido.getId() + " excluído.", false);
        } catch (SQLException e) {
            mostrarMensagem("Erro ao excluir o pedido no banco.", true);
            e.printStackTrace();
        }
    }

    // auxiliares

    @FXML
    private void voltarAoCardapio() {
        Gerenciadortela.mudarTela("cardapio.fxml", "Sistema de Restaurante - Cardápio");
    }

    //mostra a tela de confirmação
    private boolean confirmar(String texto) {
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION, texto, ButtonType.YES, ButtonType.NO);
        alerta.setTitle("Confirmação");
        alerta.setHeaderText(null);//remove o cabeçalho

        //o show ele bloqueia até ter a resposta e o orElse cobre o caso de fechar janela
        return alerta.showAndWait().orElse(ButtonType.NO) == ButtonType.YES;
    }

    //exibe mensagem, o set style caso erro seja falso verde caso seja true vermelho
    private void mostrarMensagem(String texto, boolean erro) {
        lblMensagem.setStyle(erro ? "-fx-text-fill: red;" : "-fx-text-fill: green;");
        lblMensagem.setText(texto);
    }
}
