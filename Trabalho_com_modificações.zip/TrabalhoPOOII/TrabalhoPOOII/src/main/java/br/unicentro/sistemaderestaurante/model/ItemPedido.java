package br.unicentro.sistemaderestaurante.model;

//item de um pedido ou do carrinho, prato e quantidade, guarda o nome e preço pra não ter que ficar consultando o banco
public class ItemPedido {
    private int pratoID;
    private String nomePrato;
    private double preco;
    private int quantidade;

    public ItemPedido(int pratoId, String nomePrato, double preco, int quantidade){
        this.pratoID = pratoId;
        this. nomePrato = nomePrato;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    public int getPratoID(){
        return pratoID;
    }
    public String getNomePrato(){
        return nomePrato;
    }
    public double getPreco(){
        return preco;
    }
    public int getQuantidade(){
        return quantidade;
    }
    public void setQuantidade(int quantidade){
        this.quantidade = quantidade;
    }
    public double getSubtotal() {
        return preco * quantidade;
    }
}
