package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class ExcluirPratoPedido {

    //campo para digitar o id do prato, o carrinho é estático então a instangia ve os mesmos itens de outras telas
    @FXML private TextField txtPratoId;
    private PedidoDAO pedidoDAO = new PedidoDAO();

    //le o id e remove do carrinho, se o texto não for número avisa no console
    @FXML
    private void removerDoCarrinho() {
        try {
            //converte o texto em número e mostra uma mensagem
            int pratoId = Integer.parseInt(txtPratoId.getText());
            pedidoDAO.remover(pratoId);
            System.out.println("Item removido do carrinho.");
            txtPratoId.clear();
        } catch (NumberFormatException e) {
            System.err.println("Digite um ID válido.");
        }
    }
}