package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class MudarPedido {

    @FXML private TextField txtPratoId;
    @FXML private TextField txtNovaQuantidade;

    private PedidoDAO pedidoDAO = new PedidoDAO();

    //valida os campos e altera a quantidade do prato no carrinho
    @FXML
    private void alterarQuantidade() {
        try {
            // valida se os campos não estão vazios
            if (txtPratoId.getText().isEmpty() || txtNovaQuantidade.getText().isEmpty()) {
                System.err.println("Preencha todos os campos!");
                return;
            }

            int pratoId = Integer.parseInt(txtPratoId.getText());
            int novaQtd = Integer.parseInt(txtNovaQuantidade.getText());

            // chama o método para alterar a quantidade no carrinho
            pedidoDAO.modificar(pratoId, novaQtd);
            System.out.println("Quantidade atualizada no carrinho com sucesso.");

            // limpa os campos após a alteração
            txtPratoId.clear();
            txtNovaQuantidade.clear();

        } catch (NumberFormatException e) {
            System.err.println("Digite apenas números válidos para o ID e a quantidade.");
        }
    }
}