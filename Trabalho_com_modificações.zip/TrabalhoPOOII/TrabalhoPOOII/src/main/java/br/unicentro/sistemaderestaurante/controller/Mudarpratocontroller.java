package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.model.Prato;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class Mudarpratocontroller {

    @FXML private TextField txtId;
    @FXML private TextField txtNovoNome;
    @FXML private TextField txtNovoPreco;

    //le os campos e converte o id e preco para número
    @FXML
    private void atualizarPrato() {
        try {
            int id = Integer.parseInt(txtId.getText());
            String nome = txtNovoNome.getText();
            double preco = Double.parseDouble(txtNovoPreco.getText());

            System.out.println("Prato " + id + " atualizado para: " + nome + " - R$ " + preco);
        } catch (NumberFormatException e) {
            System.err.println("Verifique os campos informados.");
        }
    }
}