package br.unicentro.sistemaderestaurante.dao;

import br.unicentro.sistemaderestaurante.model.Pedido;
import br.unicentro.sistemaderestaurante.model.ItemPedido;
import java.sql.SQLException;
import java.util.List;

public interface IPedido {
    void inserir(Pedido pedido) throws SQLException;
    void modificar(int pratoId, int novaQuantidade);
    void remover(int pratoId);
    void exibir();

    // modo administrador: operações direto no banco (o restante acima usa o carrinho em memória)
    List<Pedido> listarTodos() throws SQLException;
    List<ItemPedido> listarItens(int pedidoId) throws SQLException;
    void atualizarMesa(int pedidoId, int mesaId) throws SQLException;
    void atualizarQuantidadeItem(int pedidoId, int pratoId, int quantidade) throws SQLException;
    void excluirItem(int pedidoId, int pratoId) throws SQLException;
    void excluirPedido(int pedidoId) throws SQLException;
}