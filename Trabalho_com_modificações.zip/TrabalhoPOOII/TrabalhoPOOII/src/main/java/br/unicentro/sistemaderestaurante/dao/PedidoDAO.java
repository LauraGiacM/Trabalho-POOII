package br.unicentro.sistemaderestaurante.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import br.unicentro.sistemaderestaurante.model.ItemPedido;
import br.unicentro.sistemaderestaurante.model.Pedido;


public class PedidoDAO implements IPedido {

    //lista estática compartilhada entre telas, todas as instancias usam o mesmo carrinho por isso é estática, por isso cada tela pode criar seu próprio pedido, e ver os mesmos itens
    private static List<ItemPedido> carrinho = new ArrayList<>();

    public void adicionarItem(ItemPedido item) {
        for (ItemPedido existente : carrinho) {
            if (existente.getPratoID() == item.getPratoID()) {
                existente.setQuantidade(existente.getQuantidade() + item.getQuantidade());
                return;
            }
        }
        carrinho.add(item);
    }

//método para a tela de revisão buscr itens adicionados
    public List<ItemPedido> getCarrinho() {
        return carrinho;
    }

    //grava o pedido no banco e esvazio o carrinho
    @Override
    public void inserir(Pedido pedido) throws SQLException {
        String sqlPedido = "INSERT INTO pedido (data_hora, mesa_id) VALUES (?, ?) RETURNING id";
        String sqlItem = "INSERT INTO pedido_prato (pedido_id, prato_id, quantidade) VALUES (?, ?, ?)";

        try (Connection conexao = Conexao.getConexao()) {
            //desliga o commit automatico para os itens serem confirmados juntos
            conexao.setAutoCommit(false);
            int pedidoId = 0;

            //insere o pedido e guarda o id gerado
            try (PreparedStatement stmt = conexao.prepareStatement(sqlPedido)) {
                stmt.setTimestamp(1, Timestamp.valueOf(pedido.getDataHora()));
                stmt.setInt(2, pedido.getMesaid());
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) pedidoId = rs.getInt("id");
                }
            }

            //insere todos os itens no carrinho de uma vez
            try (PreparedStatement stmt = conexao.prepareStatement(sqlItem)) {
                for (ItemPedido item : carrinho) {
                    stmt.setInt(1, pedidoId);
                    stmt.setInt(2, item.getPratoID());
                    stmt.setInt(3, item.getQuantidade());
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }

            //confirma a transação e os itens passam a valer no banco
            conexao.commit();
            System.out.println("Pedido " + pedidoId + " gravado com " + carrinho.size() + " item(ns).");
            carrinho.clear();
        }
    }
    @Override
    public void modificar(int pratoId, int novaQtd) {
        for (ItemPedido item : carrinho) {
            if (item.getPratoID() == pratoId) {
                if (novaQtd > 0) item.setQuantidade(novaQtd);
                else remover(pratoId);
                break;
            }
        }
    }

    @Override
    public void remover(int pratoId) {
        carrinho.removeIf(item -> item.getPratoID() == pratoId);
    }

    @Override
    public void exibir() {
        for (ItemPedido item : carrinho) {
            System.out.println("Prato ID: " + item.getPratoID() + " | Qtd: " + item.getQuantidade());
        }
    }

    //modo adm
    //busca todos os pedidos no banco do mais antigo ao mais novo,
    @Override
    public List<Pedido> listarTodos() throws SQLException {
        List<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT id, data_hora, mesa_id FROM pedido ORDER BY data_hora DESC";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                pedidos.add(new Pedido(
                        rs.getInt("id"),
                        rs.getTimestamp("data_hora").toLocalDateTime(),
                        rs.getInt("mesa_id")));
            }
        }
        return pedidos;
    }

    //busca os itens de um pedido com nome e preço dele
    @Override
    public List<ItemPedido> listarItens(int pedidoId) throws SQLException {
        List<ItemPedido> itens = new ArrayList<>();
        String sql = "SELECT pp.prato_id, p.nome, p.preco, pp.quantidade "
                + "FROM pedido_prato pp JOIN prato p ON p.id = pp.prato_id "
                + "WHERE pp.pedido_id = ? ORDER BY p.nome";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, pedidoId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    itens.add(new ItemPedido(
                            rs.getInt("prato_id"),
                            rs.getString("nome"),
                            rs.getDouble("preco"),
                            rs.getInt("quantidade")));
                }
            }
        }
        return itens;
    }

    //troca a mesa do pedido informado
    @Override
    public void atualizarMesa(int pedidoId, int mesaId) throws SQLException {
        String sql = "UPDATE pedido SET mesa_id = ? WHERE id = ?";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, mesaId);
            stmt.setInt(2, pedidoId);
            stmt.executeUpdate();
        }
    }

    //altera a quantidade de um item de um pedido já salvo
    @Override
    public void atualizarQuantidadeItem(int pedidoId, int pratoId, int quantidade) throws SQLException {
        String sql = "UPDATE pedido_prato SET quantidade = ? WHERE pedido_id = ? AND prato_id = ?";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, quantidade);
            stmt.setInt(2, pedidoId);
            stmt.setInt(3, pratoId);
            stmt.executeUpdate();
        }
    }

    //remove um prato de um pedido salvo
    @Override
    public void excluirItem(int pedidoId, int pratoId) throws SQLException {
        String sql = "DELETE FROM pedido_prato WHERE pedido_id = ? AND prato_id = ?";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, pedidoId);
            stmt.setInt(2, pratoId);
            stmt.executeUpdate();
        }
    }

    //exlui um pedido em usa só transação
    @Override
    public void excluirPedido(int pedidoId) throws SQLException {

        String sqlItens = "DELETE FROM pedido_prato WHERE pedido_id = ?";
        String sqlPedido = "DELETE FROM pedido WHERE id = ?";

        try (Connection conexao = Conexao.getConexao()) {
            conexao.setAutoCommit(false);

            try (PreparedStatement stmtItens = conexao.prepareStatement(sqlItens);
                 PreparedStatement stmtPedido = conexao.prepareStatement(sqlPedido)) {

                stmtItens.setInt(1, pedidoId);
                stmtItens.executeUpdate();

                stmtPedido.setInt(1, pedidoId);
                stmtPedido.executeUpdate();

                conexao.commit();
            } catch (SQLException e) {
                //se algo falhar, desfaz toda a transação
                conexao.rollback();
                throw e;
            }
        }
    }
}