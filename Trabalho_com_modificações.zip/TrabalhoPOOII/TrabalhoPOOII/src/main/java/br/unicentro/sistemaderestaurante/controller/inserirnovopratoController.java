package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PratoDAO;
import br.unicentro.sistemaderestaurante.model.Prato;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.sql.SQLException;

//controla o cadastro de novo prato
public class inserirnovopratoController {

    @FXML private TextField txtNome;
    @FXML private TextField txtPreco;
    @FXML private TextField txtFuncionarioId;

    private PratoDAO pratoDAO = new PratoDAO();

    //lê o formulário e valida o preço e funcionário e grava o prato no banco, limpa os campos se der certo
    @FXML
    private void salvarPrato() {
        try {
            String nome = txtNome.getText();
            double preco = Double.parseDouble(txtPreco.getText());
            int funcionarioId = Integer.parseInt(txtFuncionarioId.getText());

            //id 0 pq o prato não existe, o banco vai gerar o id real ao adicionar no banco
            Prato prato = new Prato(0, nome, preco, funcionarioId);
            pratoDAO.inserir(prato);

            limparCampos();
            System.out.println("Prato cadastrado com sucesso!");

        } catch (NumberFormatException e) {
            System.err.println("Por favor, insira valores válidos para preço e funcionário.");
        } catch (SQLException e) {
            System.err.println("Erro ao cadastrar prato: " + e.getMessage());
        }
    }

    //esvazio os campos do formulário
    private void limparCampos() {
        txtNome.clear();
        txtPreco.clear();
        txtFuncionarioId.clear();
    }
}