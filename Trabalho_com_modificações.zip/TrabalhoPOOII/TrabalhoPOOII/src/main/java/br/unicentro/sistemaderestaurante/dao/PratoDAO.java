package br.unicentro.sistemaderestaurante.dao;

import br.unicentro.sistemaderestaurante.model.Prato;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//acessa os protos no banco de dados
public class PratoDAO implements IPrato {

    //insere um prato novo e atualiza o objeto recebido com o id que o banco gera
    @Override
    public void inserir(Prato prato) throws SQLException {
        //reurning id devolve o id que o banco gerou para o novo prato
        String sql = "INSERT INTO prato (nome, preco, funcionario_id) VALUES (?, ?, ?) RETURNING id";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, prato.getNome());
            stmt.setDouble(2, prato.getPreco());
            stmt.setInt(3, prato.getFuncionarioId());

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    //guardo no objeto o id
                    prato.setId(rs.getInt("id"));
                }
            }
        }
    }

    @Override
    public List<Prato> listarTodos() throws SQLException {
        List<Prato> pratos = new ArrayList<>();
        String sql = "SELECT id, nome, preco, funcionario_id FROM prato ORDER BY id";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                //monta um objeto prato com os dados da linha atual
                Prato prato = new Prato();
                prato.setId(rs.getInt("id"));
                prato.setNome(rs.getString("nome"));
                prato.setPreco(rs.getDouble("preco"));
                prato.setFuncionarioId(rs.getInt("funcionario_id"));
                pratos.add(prato);
            }
        }
        return pratos;
    }

    @Override
    public void atualizar(Prato prato) throws SQLException {
        String sql = "UPDATE prato SET nome = ?, preco = ?, funcionario_id = ? WHERE id = ?";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, prato.getNome());
            stmt.setDouble(2, prato.getPreco());
            stmt.setInt(3, prato.getFuncionarioId());
            stmt.setInt(4, prato.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM prato WHERE id = ?";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}