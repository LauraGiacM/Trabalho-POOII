package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class InserirPratoPedido {

    @FXML private TextField txtPratoId;
    @FXML private TextField txtQuantidade;

    private PedidoDAO pedidoDAO = new PedidoDAO();

    //le o id e a quantidade e envia ao carrinho
    @FXML
    private void adicionarAoCarrinho() {
        try {
            int pratoId = Integer.parseInt(txtPratoId.getText());
            int qtd = Integer.parseInt(txtQuantidade.getText());

            // adiciona ao carrinho mantio do pedido
            //o modificar altera itens que já estão no carrinho
            pedidoDAO.modificar(pratoId, qtd);
            System.out.println("Item adicionado ao carrinho!");

            //limpa os campos para a próxima inserção
            txtPratoId.clear();
            txtQuantidade.clear();
        } catch (NumberFormatException e) {
            System.err.println("Digite números válidos para ID e Quantidade.");
        }
    }
}