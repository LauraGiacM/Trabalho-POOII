package br.unicentro.sistemaderestaurante.main;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        Gerenciadortela.setPrimaryStage(primaryStage);

        Gerenciadortela.mudarTela("cardapio.fxml", "Sistema de Restaurante - Cardápio");
    }

    public static void main(String[] args) {
        launch(args);
    }
}