package br.unicentro.sistemaderestaurante.model;
import java.time.LocalDateTime;

public class Pedido {
    private int id;
    private LocalDateTime dataHora;
    private int mesaid;

    public Pedido(int mesaid){
        this.mesaid = mesaid;
        this.dataHora = LocalDateTime.now();
    }

    // Usado ao carregar um pedido já existente do banco
    public Pedido(int id, LocalDateTime dataHora, int mesaid){
        this.id = id;
        this.dataHora = dataHora;
        this.mesaid = mesaid;
    }

    public int getId(){return id;}
    public LocalDateTime getDataHora(){return dataHora;}
    public int getMesaid(){return mesaid;}



}
