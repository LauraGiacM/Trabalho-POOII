package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import br.unicentro.sistemaderestaurante.main.Gerenciadortela;
import br.unicentro.sistemaderestaurante.model.ItemPedido;
import javafx.fxml.FXML;

public class exibirmenuController {

   //cada botão do prato adiciona cria um ItemPedido e adiciona ele no carrinho
    //os ids ficam fixos para corresponder com o que está no banco
    private PedidoDAO pedidoDAO = new PedidoDAO();

    //botões dos pratos usados para adicionar 1 unidade do prato selecionado no carrinho
    @FXML
    private void adicionarFileParmegiana() {

        ItemPedido item = new ItemPedido(1, "Filé à Parmegiana", 65.90, 1);

        pedidoDAO.adicionarItem(item);

        System.out.println("Filé à Parmegiana adicionado ao carrinho!");
    }

    @FXML
    private void adicionarBifecomBatata() {
        ItemPedido item = new ItemPedido(2, "Bife com Batata", 55.00, 1);

        pedidoDAO.adicionarItem(item);

        System.out.println("Bife com batatas adicionado ao carrinho!");
    }

    @FXML
    private void adicionarSpaghettiCarbonara(){
        ItemPedido item = new ItemPedido(3, "Spaghetti Carbonara", 48.00, 1);
        pedidoDAO.adicionarItem(item);
        System.out.println("Spaguetti Carbonara adicionado ao carrinho!");
    }

    @FXML
    private void adicionarSaladaCeasar(){
        ItemPedido item = new ItemPedido(4, "Salada Ceasar", 32.50, 1);
        pedidoDAO.adicionarItem(item);
        System.out.println("Salada Ceasar adicionado ao carrinho!");
    }

    @FXML
    private void adicionarFonduedeQueijo(){
        ItemPedido item = new ItemPedido(5, "Fundue de queijo", 120.00, 1);
        pedidoDAO.adicionarItem(item);
        System.out.println("Fondue de Queijo adicionado ao carrinho!");
    }

    @FXML
    private void adicionarFunduedeChocolate(){
        ItemPedido item = new ItemPedido(6, "Fundue de Chocolate", 95.00, 1);
        pedidoDAO.adicionarItem(item);
        System.out.println("Fondue de Chocolate adicionado ao carrinho!");
    }

    @FXML
    private void adicionarBrusquetadeSalmao(){
        ItemPedido item = new ItemPedido(7, "Brusqueta de Salmão", 42.00, 1);
        pedidoDAO.adicionarItem(item);
        System.out.println("Brusqueta de Salmão adicionado ao carrinho!");
    }

    @FXML
    private void adicionarPetitGateau(){
        ItemPedido item = new ItemPedido(8, "Petit Gâteau", 24.00, 1);
        pedidoDAO.adicionarItem(item);
        System.out.println("Petiti Gâteau adicionado ao carrinho!");
    }

    //abre a tela no modo administrador
    @FXML
    private void abrirModoAdmin() {
        Gerenciadortela.mudarTela("admin.fxml", "Modo Administrador");
    }

    //abre a tela de revisão do carrinho
    @FXML
    private void irParaRevisaoCarrinho() {
        //chama o gerenciador para carregar o arquivo da revisão de carrinho
        Gerenciadortela.mudarTela("revisaocarrinho.fxml", "Revisão do Carrinho");
    }

}