package br.unicentro.sistemaderestaurante.model;

public class Prato {
    private int id;
    private String nome;
    private double preco;
    private int funcionarioId;

    public Prato() {}

    public Prato(int id, String nome, double preco, int funcionarioId) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.funcionarioId = funcionarioId;
    }

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }

    public int getFuncionarioId() { return funcionarioId; }
    public void setFuncionarioId(int funcionarioId) { this.funcionarioId = funcionarioId; }
}