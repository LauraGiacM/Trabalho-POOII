package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import br.unicentro.sistemaderestaurante.model.ItemPedido;
import br.unicentro.sistemaderestaurante.model.Pedido;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;
//controla a exibição do pedido, aqui ele usa uma lista local mas na revisão usa o carrinho mesmo
public class exibirPedidoController {

    @FXML private TableView<ItemPedido> tabelaCarrinho;
    @FXML private TableColumn<ItemPedido, String> colNome;
    @FXML private TableColumn<ItemPedido, Integer> colQuantidade;
    @FXML private TableColumn<ItemPedido, Double> colSubtotal;
    @FXML private Label lblPrecoTotal;
    @FXML private Label lblQtdItens;
    @FXML private Button btnFinalizar;

   //lista para o JavaFX atualizar a tabela automaticamente
    private ObservableList<ItemPedido> listaItens = FXCollections.observableArrayList();

    //liga as colunas aos atributos e a tabela a lista
    @FXML
    public void initialize() {
        // configura as colunas com base na itemPedido
        colNome.setCellValueFactory(new PropertyValueFactory<>("nomePrato"));
        colQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
        colSubtotal.setCellValueFactory(new PropertyValueFactory<>("preco")); // ou criar um método getSubtotal()

        tabelaCarrinho.setItems(listaItens);
        atualizarTotais();
    }

    // método que recebe os pratos vindos do cardápio
    //adiciona um item a lista exibida e atualiza o valor
    public void adicionarItemAoCarrinho(ItemPedido item) {
        listaItens.add(item);
        atualizarTotais();
    }

    //recalcula o preço total e a quantidade total de itens
    private void atualizarTotais() {
        double total = 0;
        int qtdItens = 0;
        for (ItemPedido item : listaItens) {
            total += item.getPreco() * item.getQuantidade();
            qtdItens += item.getQuantidade();
        }
        lblPrecoTotal.setText(String.format("Preço Total: R$ %.2f", total));
        lblQtdItens.setText("Quantidade de itens: " + qtdItens);
    }

    //salva o pedido no banco e esvazia a lista
    @FXML
    private void finalizarPedido() {
        if (listaItens.isEmpty()) {
            System.out.println("O carrinho está vazio!");
            return;
        }

        try {
            // exemplo que fixa na mesa 1
            Pedido pedido = new Pedido(1);
            PedidoDAO pedidoDAO = new PedidoDAO();

            // passa os itens do carrinho para dao para salvar no banco
            pedidoDAO.inserir(pedido);

            System.out.println("Pedido finalizado com sucesso no banco!");
            listaItens.clear();
            atualizarTotais();

        } catch (SQLException e) {
            System.err.println("Erro ao finalizar pedido: " + e.getMessage());
        }
    }
}