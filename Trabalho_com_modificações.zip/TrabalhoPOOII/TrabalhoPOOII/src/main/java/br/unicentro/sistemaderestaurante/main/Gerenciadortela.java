package br.unicentro.sistemaderestaurante.main;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Gerenciadortela {

    private static Stage primaryStage;

    public static void setPrimaryStage(Stage stage) {
        primaryStage = stage;
    }

    public static void mudarTela(String fxmlFile, String titulo) {
        try {

            FXMLLoader loader = new FXMLLoader(Gerenciadortela.class.getResource("/br/unicentro/sistemaderestaurante/view/" + fxmlFile));
            Parent root = loader.load();

            if (primaryStage == null) {
                primaryStage = new Stage();
            }

            primaryStage.setTitle(titulo);
            primaryStage.setScene(new Scene(root));
            primaryStage.show();

        } catch (IOException e) {
            System.err.println("Erro ao carregar a tela: " + fxmlFile);
            e.printStackTrace();
        }
    }
}