package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PratoDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class excluirpratoController {

    //campo onde fica o id do prato que quer excluir
    @FXML private TextField txtPratoId;
    private PratoDAO pratoDAO = new PratoDAO();

    //le o id e converte e avisa se for inválido
    @FXML
    private void excluirPrato() {
        try {
            int id = Integer.parseInt(txtPratoId.getText());
            // Chama a exclusão no banco (pode implementar no PratoDAO se necessário)
            System.out.println("Prato ID " + id + " removido.");
            txtPratoId.clear();
        } catch (NumberFormatException e) {
            System.err.println("Informe um ID válido.");
        }
    }
}