module br.unicentro.sistemaderestaurante {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    // Permite que o JavaFX acesse as views e controllers
    opens br.unicentro.sistemaderestaurante.main to javafx.fxml;
    opens br.unicentro.sistemaderestaurante.controller to javafx.fxml;

    // Exporta os pacotes principais
    exports br.unicentro.sistemaderestaurante.main;
    exports br.unicentro.sistemaderestaurante.controller;
    exports br.unicentro.sistemaderestaurante.model;
    exports br.unicentro.sistemaderestaurante.dao;
}