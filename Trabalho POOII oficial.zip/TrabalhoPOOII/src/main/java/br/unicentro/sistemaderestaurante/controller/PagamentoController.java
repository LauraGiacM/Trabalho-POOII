package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import br.unicentro.sistemaderestaurante.model.Pedido;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class PagamentoController {

    @FXML private TextField txtNomeCliente;
    @FXML private TextField txtQtdPessoas;
    @FXML private ComboBox<String> cbFormaPagamento;
    @FXML private ComboBox<Integer> cbMesa;
    @FXML private Button btnSolicitar;
    @FXML private Label lblMensagem;
    private PedidoDAO pedidoDAO = new PedidoDAO();

    @FXML
    public void initialize() {
        // Preenche as formas de pagamento
        cbFormaPagamento.setItems(FXCollections.observableArrayList(
                "Dinheiro", "Cartão de Crédito", "Cartão de Débito", "Pix"
        ));

        // Preenche as mesas de 1 a 13 (conforme o escopo do seu banco)
        Integer[] mesas = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
        cbMesa.setItems(FXCollections.observableArrayList(mesas));

        // Garante que a mensagem começa vazia
        lblMensagem.setText("");
    }

    @FXML
    private void irParaPagamento() {
        String nome = txtNomeCliente.getText();
        String qtdPessoasStr = txtQtdPessoas.getText();
        String formaPagamento = cbFormaPagamento.getValue();
        Integer mesaSelecionada = cbMesa.getValue();

        // Validação simples para preenchimento obrigatório
        if (nome.isEmpty() || qtdPessoasStr.isEmpty() || formaPagamento == null || mesaSelecionada == null) {
            lblMensagem.setStyle("-fx-text-fill: red;");
            lblMensagem.setText("Por favor, preencha todos os campos!");
            return;
        }

        try {
            int qtdPessoas = Integer.parseInt(qtdPessoasStr);
            if (qtdPessoas <= 0) {
                lblMensagem.setStyle("-fx-text-fill: red;");
                lblMensagem.setText("A quantidade de pessoas deve ser maior que zero.");
                return;
            }

            // Não salva pedido sem itens
            if (pedidoDAO.getCarrinho().isEmpty()) {
                lblMensagem.setStyle("-fx-text-fill: red;");
                lblMensagem.setText("O carrinho está vazio!");
                return;
            }

            // Salva no banco (pedido + itens) e limpa o carrinho
            pedidoDAO.inserir(new Pedido(mesaSelecionada));

            lblMensagem.setStyle("-fx-text-fill: green;");
            lblMensagem.setText("Solicitação enviada! Um atendente está indo até a Mesa "
                    + mesaSelecionada + " para efetuar o pagamento.");

            limparCampos();

        } catch (NumberFormatException e) {
            lblMensagem.setStyle("-fx-text-fill: red;");
            lblMensagem.setText("A quantidade de pessoas deve ser um número válido.");
        } catch (SQLException e) {
            lblMensagem.setStyle("-fx-text-fill: red;");
            lblMensagem.setText("Erro ao salvar o pedido no banco.");
            e.printStackTrace();
        }
    }

    private void limparCampos() {
        txtNomeCliente.clear();
        txtQtdPessoas.clear();
        cbFormaPagamento.getSelectionModel().clearSelection();
        cbMesa.getSelectionModel().clearSelection();
    }
}