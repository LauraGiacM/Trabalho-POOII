package br.unicentro.sistemaderestaurante.model;
import java.time.LocalDateTime;

public class Pedido {
    private int id;
    private LocalDateTime dataHora;
    private int mesaid;

    public Pedido(int mesaid){
        this.mesaid = mesaid;
        this.dataHora = LocalDateTime.now();
    }

    public int getId(){return id;}
    public LocalDateTime getDataHora(){return dataHora;}
    public int getMesaid(){return mesaid;}



}
