package br.unicentro.sistemaderestaurante.dao;

import br.unicentro.sistemaderestaurante.model.Prato;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PratoDAO implements IPrato {

    @Override
    public void inserir(Prato prato) throws SQLException {
        String sql = "INSERT INTO prato (nome, preco, funcionario_id) VALUES (?, ?, ?) RETURNING id";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, prato.getNome());
            stmt.setDouble(2, prato.getPreco());
            stmt.setInt(3, prato.getFuncionarioId());

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    prato.setId(rs.getInt("id"));
                }
            }
        }
    }

    @Override
    public List<Prato> listarTodos() throws SQLException {
        List<Prato> pratos = new ArrayList<>();
        String sql = "SELECT id, nome, preco, funcionario_id FROM prato";

        try (Connection conexao = Conexao.getConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Prato prato = new Prato();
                prato.setId(rs.getInt("id"));
                prato.setNome(rs.getString("nome"));
                prato.setPreco(rs.getDouble("preco"));
                prato.setFuncionarioId(rs.getInt("funcionario_id"));
                pratos.add(prato);
            }
        }
        return pratos;
    }
}