package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class InserirPratoPedido {

    @FXML private TextField txtPratoId;
    @FXML private TextField txtQuantidade;

    private PedidoDAO pedidoDAO = new PedidoDAO();

    @FXML
    private void adicionarAoCarrinho() {
        try {
            int pratoId = Integer.parseInt(txtPratoId.getText());
            int qtd = Integer.parseInt(txtQuantidade.getText());

            // Adiciona ao carrinho mantido no PedidoDAO
            pedidoDAO.modificar(pratoId, qtd);
            System.out.println("Item adicionado ao carrinho!");

            txtPratoId.clear();
            txtQuantidade.clear();
        } catch (NumberFormatException e) {
            System.err.println("Digite números válidos para ID e Quantidade.");
        }
    }
}