package br.unicentro.sistemaderestaurante.dao;

import br.unicentro.sistemaderestaurante.model.Prato;
import java.sql.SQLException;
import java.util.List;

public interface IPrato {
    void inserir(Prato prato) throws SQLException;
    List<Prato> listarTodos() throws SQLException;
}