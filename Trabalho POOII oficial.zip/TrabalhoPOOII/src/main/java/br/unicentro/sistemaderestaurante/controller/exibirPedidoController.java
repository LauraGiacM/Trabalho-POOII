package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import br.unicentro.sistemaderestaurante.model.ItemPedido;
import br.unicentro.sistemaderestaurante.model.Pedido;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;

public class exibirPedidoController {

    @FXML private TableView<ItemPedido> tabelaCarrinho;
    @FXML private TableColumn<ItemPedido, String> colNome;
    @FXML private TableColumn<ItemPedido, Integer> colQuantidade;
    @FXML private TableColumn<ItemPedido, Double> colSubtotal;
    @FXML private Label lblPrecoTotal;
    @FXML private Label lblQtdItens;
    @FXML private Button btnFinalizar;

    // Lista observável para o JavaFX atualizar a tabela automaticamente
    private ObservableList<ItemPedido> listaItens = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Configura as colunas com base nos atributos da classe ItemPedido
        colNome.setCellValueFactory(new PropertyValueFactory<>("nomePrato"));
        colQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
        colSubtotal.setCellValueFactory(new PropertyValueFactory<>("preco")); // ou criar um método getSubtotal()

        tabelaCarrinho.setItems(listaItens);
        atualizarTotais();
    }

    // Método para receber pratos vindos da tela de cardápio
    public void adicionarItemAoCarrinho(ItemPedido item) {
        listaItens.add(item);
        atualizarTotais();
    }

    private void atualizarTotais() {
        double total = 0;
        int qtdItens = 0;
        for (ItemPedido item : listaItens) {
            total += item.getPreco() * item.getQuantidade();
            qtdItens += item.getQuantidade();
        }
        lblPrecoTotal.setText(String.format("Preço Total: R$ %.2f", total));
        lblQtdItens.setText("Quantidade de itens: " + qtdItens);
    }

    @FXML
    private void finalizarPedido() {
        if (listaItens.isEmpty()) {
            System.out.println("O carrinho está vazio!");
            return;
        }

        try {
            // Exemplo fixando a Mesa 1 por enquanto (ou pegando de um ComboBox)
            Pedido pedido = new Pedido(1);
            PedidoDAO pedidoDAO = new PedidoDAO();

            // Passa os itens do carrinho para o DAO salvar no banco
            // (Certifique-se de que o seu PedidoDAO lê os itens da lista ou receba-os)
            pedidoDAO.inserir(pedido);

            System.out.println("Pedido finalizado com sucesso no banco!");
            listaItens.clear();
            atualizarTotais();

        } catch (SQLException e) {
            System.err.println("Erro ao finalizar pedido: " + e.getMessage());
        }
    }
}