package br.unicentro.sistemaderestaurante.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import br.unicentro.sistemaderestaurante.model.ItemPedido;
import br.unicentro.sistemaderestaurante.model.Pedido;

public class PedidoDAO implements IPedido {

    // Lista estática compartilhada entre as telas
    private static List<ItemPedido> carrinho = new ArrayList<>();

    public void adicionarItem(ItemPedido item) {
        for (ItemPedido existente : carrinho) {
            if (existente.getPratoID() == item.getPratoID()) {
                existente.setQuantidade(existente.getQuantidade() + item.getQuantidade());
                return;
            }
        }
        carrinho.add(item);
    }

    // Método para a tela de revisão buscar os itens adicionados
    public List<ItemPedido> getCarrinho() {
        return carrinho;
    }

    @Override
    public void inserir(Pedido pedido) throws SQLException {
        String sqlPedido = "INSERT INTO pedido (data_hora, mesa_id) VALUES (?, ?) RETURNING id";
        String sqlItem = "INSERT INTO pedido_prato (pedido_id, prato_id, quantidade) VALUES (?, ?, ?)";

        try (Connection conexao = Conexao.getConexao()) {
            conexao.setAutoCommit(false);
            int pedidoId = 0;

            try (PreparedStatement stmt = conexao.prepareStatement(sqlPedido)) {
                stmt.setTimestamp(1, Timestamp.valueOf(pedido.getDataHora()));
                stmt.setInt(2, pedido.getMesaid());
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) pedidoId = rs.getInt("id");
                }
            }

            try (PreparedStatement stmt = conexao.prepareStatement(sqlItem)) {
                for (ItemPedido item : carrinho) {
                    stmt.setInt(1, pedidoId);
                    stmt.setInt(2, item.getPratoID());
                    stmt.setInt(3, item.getQuantidade());
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }

            conexao.commit();
            System.out.println("Pedido " + pedidoId + " gravado com " + carrinho.size() + " item(ns).");
            carrinho.clear(); // Limpa após finalizar
        }
    }
    @Override
    public void modificar(int pratoId, int novaQtd) {
        for (ItemPedido item : carrinho) {
            if (item.getPratoID() == pratoId) {
                if (novaQtd > 0) item.setQuantidade(novaQtd);
                else remover(pratoId);
                break;
            }
        }
    }

    @Override
    public void remover(int pratoId) {
        carrinho.removeIf(item -> item.getPratoID() == pratoId);
    }

    @Override
    public void exibir() {
        for (ItemPedido item : carrinho) {
            System.out.println("Prato ID: " + item.getPratoID() + " | Qtd: " + item.getQuantidade());
        }
    }
}