package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class ExcluirPratoPedido {

    @FXML private TextField txtPratoId;
    private PedidoDAO pedidoDAO = new PedidoDAO();

    @FXML
    private void removerDoCarrinho() {
        try {
            int pratoId = Integer.parseInt(txtPratoId.getText());
            pedidoDAO.remover(pratoId);
            System.out.println("Item removido do carrinho.");
            txtPratoId.clear();
        } catch (NumberFormatException e) {
            System.err.println("Digite um ID válido.");
        }
    }
}