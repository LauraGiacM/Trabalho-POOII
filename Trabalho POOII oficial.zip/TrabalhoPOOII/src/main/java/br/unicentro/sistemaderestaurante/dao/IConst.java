package br.unicentro.sistemaderestaurante.dao;

public interface IConst {

    String MSG_CARRINHO_VAZIO = "O carrinho de compras está vazio.";

    String MSG_PEDIDO_SUCESSO = "Pedido finalizado e salvo com sucesso!";

    String MSG_ITEM_REMOVIDO = "Item removido do carrinho.";

    String MSG_ITEM_NAO_ENCONTRADO = "Item não encontrado no carrinho.";

    String stringDeConexao = "jdbc:postgresql://localhost:5432/Restaurante";

    String usuario = "postgres";

    String senha = "postgres";
}