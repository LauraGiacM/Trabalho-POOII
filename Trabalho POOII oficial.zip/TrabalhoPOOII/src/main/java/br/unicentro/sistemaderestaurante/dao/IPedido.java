package br.unicentro.sistemaderestaurante.dao;

import br.unicentro.sistemaderestaurante.model.Pedido;
import java.sql.SQLException;

public interface IPedido {
    void inserir(Pedido pedido) throws SQLException;
    void modificar(int pratoId, int novaQuantidade);
    void remover(int pratoId);
    void exibir();
}