package br.unicentro.sistemaderestaurante.controller;

import br.unicentro.sistemaderestaurante.dao.IConst;
import br.unicentro.sistemaderestaurante.dao.PedidoDAO;
import br.unicentro.sistemaderestaurante.dao.PratoDAO;
import br.unicentro.sistemaderestaurante.main.Gerenciadortela;
import br.unicentro.sistemaderestaurante.model.ItemPedido;
import br.unicentro.sistemaderestaurante.model.Prato;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.util.StringConverter;

public class RevisaoCarrinhoController {

    @FXML private TableView<ItemPedido> tabelaCarrinho;
    @FXML private TableColumn<ItemPedido, String> colunaNomePrato;
    @FXML private TableColumn<ItemPedido, Integer> colunaQuantidade;
    @FXML private TableColumn<ItemPedido, Double> colunaSubtotal;
    @FXML private Label lblPrecoTotal;
    @FXML private Label lblQtdItens;
    @FXML private Label lblMensagem;
    @FXML private ComboBox<Prato> cbPratos;
    @FXML private Spinner<Integer> spQuantidade;

    private final PedidoDAO pedidoDAO = new PedidoDAO();
    private final PratoDAO pratoDAO = new PratoDAO();

    @FXML
    public void initialize() {
        // Configura as colunas para pegarem os atributos corretos de ItemPedido
        colunaNomePrato.setCellValueFactory(new PropertyValueFactory<>("nomePrato"));
        colunaQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
        colunaSubtotal.setCellValueFactory(new PropertyValueFactory<>("subtotal"));

        // Quantidade de 1 a 99, começando em 1
        spQuantidade.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 99, 1));

        // Tecla Delete remove o prato selecionado na tabela
        tabelaCarrinho.setOnKeyPressed(evento -> {
            if (evento.getCode() == KeyCode.DELETE) {
                removerPrato();
            }
        });

        configurarComboPratos();
        carregarPratos();
        atualizarTela();
        lblMensagem.setText("");
    }

    // ---------- Adicionar prato ----------

    @FXML
    private void adicionarPrato() {
        Prato prato = cbPratos.getValue();
        if (prato == null) {
            mostrarMensagem("Escolha um prato para adicionar.", true);
            return;
        }

        int quantidade;
        try {
            spQuantidade.increment(0); // confirma o que foi digitado no campo
            Integer valor = spQuantidade.getValue();
            if (valor == null || valor < 1 || valor > 99) {
                mostrarMensagem("Informe uma quantidade entre 1 e 99.", true);
                return;
            }
            quantidade = valor;
        } catch (RuntimeException e) {
            mostrarMensagem("Informe uma quantidade válida (1 a 99).", true);
            return;
        }

        // Se o prato já está no carrinho, o DAO soma as quantidades
        pedidoDAO.adicionarItem(new ItemPedido(prato.getId(), prato.getNome(), prato.getPreco(), quantidade));

        spQuantidade.getValueFactory().setValue(1);
        mostrarMensagem(quantidade + "x " + prato.getNome() + " adicionado ao carrinho.", false);
        atualizarTela();
    }

    // excluir

    @FXML
    private void removerPrato() {
        ItemPedido selecionado = tabelaCarrinho.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            mostrarMensagem("Selecione um prato na tabela para remover.", true);
            return;
        }

        pedidoDAO.remover(selecionado.getPratoID());
        mostrarMensagem(selecionado.getNomePrato() + ": " + IConst.MSG_ITEM_REMOVIDO, false);
        atualizarTela();
    }

    // navegar

    @FXML
    private void voltarAoCardapio() {
        Gerenciadortela.mudarTela("cardapio.fxml", "Sistema de Restaurante - Cardápio");
    }

    @FXML
    private void irParaPagamento() {
        if (pedidoDAO.getCarrinho().isEmpty()) {
            mostrarMensagem(IConst.MSG_CARRINHO_VAZIO, true);
            return;
        }
        Gerenciadortela.mudarTela("pagamento.fxml", "Pagamento do Pedido");
    }

    // auxiliares

    private void configurarComboPratos() {
        // Mostra "Nome - R$ preço" no lugar do toString() do Prato
        cbPratos.setConverter(new StringConverter<Prato>() {
            @Override
            public String toString(Prato prato) {
                return prato == null ? "" : String.format("%s - R$ %.2f", prato.getNome(), prato.getPreco());
            }

            @Override
            public Prato fromString(String texto) {
                return null; // o ComboBox não é editável
            }
        });
    }

    private void carregarPratos() {
        try {
            List<Prato> pratos = pratoDAO.listarTodos();
            pratos.sort(Comparator.comparing(Prato::getNome, String.CASE_INSENSITIVE_ORDER));
            cbPratos.setItems(FXCollections.observableArrayList(pratos));
        } catch (SQLException e) {
            mostrarMensagem("Não foi possível carregar os pratos do banco.", true);
            System.err.println("Erro ao listar pratos: " + e.getMessage());
        }
    }

    private void atualizarTela() {
        // Recria a lista para a tabela repintar (ItemPedido não é observável)
        tabelaCarrinho.setItems(FXCollections.observableArrayList(pedidoDAO.getCarrinho()));
        atualizarTotais();
    }

    private void atualizarTotais() {
        double total = 0;
        int qtdItens = 0;
        for (ItemPedido item : pedidoDAO.getCarrinho()) {
            total += item.getSubtotal();
            qtdItens += item.getQuantidade();
        }
        lblPrecoTotal.setText(String.format("Preço total: R$ %.2f", total));
        lblQtdItens.setText("Itens no Carrinho: " + qtdItens);
    }

    private void mostrarMensagem(String texto, boolean erro) {
        lblMensagem.setStyle(erro ? "-fx-text-fill: red;" : "-fx-text-fill: green;");
        lblMensagem.setText(texto);
    }
}